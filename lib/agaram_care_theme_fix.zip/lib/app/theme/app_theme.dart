import 'package:flutter/material.dart';

/// Central theme definitions for Agaram Care.
///
/// Screens should read colors from `Theme.of(context).colorScheme` and text
/// styles from `Theme.of(context).textTheme` instead of hard-coded colors,
/// so the UI stays readable across light, dark and system theme modes.
class AppTheme {
  AppTheme._();

  /// Brand teal. Kept public because the splash screen intentionally shows
  /// a fixed brand-colored background regardless of the active theme mode.
  static const Color primary = Color(0xFF0B6E69);

  // Light palette.
  static const Color _lightBackground = Color(0xFFF6F8F7);
  static const Color _lightSurface = Colors.white;
  static const Color _lightOnSurface = Color(0xFF17201F);
  static const Color _lightOnSurfaceVariant = Color(0xFF65716F);
  static const Color _lightOutline = Color(0xFFE0E6E4);

  // Dark palette.
  static const Color _darkBackground = Color(0xFF101514);
  static const Color _darkSurface = Color(0xFF18201F);
  static const Color _darkOnSurface = Color(0xFFF1F5F4);
  static const Color _darkOnSurfaceVariant = Color(0xFFB8C4C1);
  static const Color _darkOutline = Color(0xFF35413F);
  static const Color _darkPrimary = Color(0xFF4DB6AE);

  static ThemeData get lightTheme => _buildTheme(
        background: _lightBackground,
        colorScheme: ColorScheme.fromSeed(
          seedColor: primary,
          brightness: Brightness.light,
        ).copyWith(
          primary: primary,
          onPrimary: Colors.white,
          surface: _lightSurface,
          onSurface: _lightOnSurface,
          onSurfaceVariant: _lightOnSurfaceVariant,
          outline: _lightOutline,
          outlineVariant: _lightOutline,
        ),
      );

  static ThemeData get darkTheme => _buildTheme(
        background: _darkBackground,
        colorScheme: ColorScheme.fromSeed(
          seedColor: primary,
          brightness: Brightness.dark,
        ).copyWith(
          primary: _darkPrimary,
          onPrimary: Colors.black,
          surface: _darkSurface,
          onSurface: _darkOnSurface,
          onSurfaceVariant: _darkOnSurfaceVariant,
          outline: _darkOutline,
          outlineVariant: _darkOutline,
        ),
      );

  /// Builds a full theme from a [colorScheme] so both modes stay in sync:
  /// every screen-level style below is derived from the scheme instead of
  /// being re-specified per brightness.
  static ThemeData _buildTheme({
    required Color background,
    required ColorScheme colorScheme,
  }) {
    final base = ThemeData(
      useMaterial3: true,
      brightness: colorScheme.brightness,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: background,
    );

    return base.copyWith(
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: colorScheme.onSurface,
        elevation: 0,
      ),
      textTheme: base.textTheme.copyWith(
        bodyMedium: base.textTheme.bodyMedium?.copyWith(
          color: colorScheme.onSurfaceVariant,
        ),
        bodySmall: base.textTheme.bodySmall?.copyWith(
          color: colorScheme.onSurfaceVariant,
        ),
      ),
      iconTheme: IconThemeData(color: colorScheme.onSurfaceVariant),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: colorScheme.primary,
          foregroundColor: colorScheme.onPrimary,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: colorScheme.surface,
        labelStyle: TextStyle(color: colorScheme.onSurfaceVariant),
        hintStyle: TextStyle(color: colorScheme.onSurfaceVariant),
        prefixIconColor: colorScheme.onSurfaceVariant,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colorScheme.outlineVariant),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colorScheme.outlineVariant),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colorScheme.primary, width: 1.5),
        ),
      ),
    );
  }
}
