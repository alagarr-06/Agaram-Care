﻿import 'package:flutter/material.dart';

class AppLocalizations {
  const AppLocalizations(this.locale);

  final Locale locale;

  bool get isTamil => locale.languageCode == 'ta';
  bool get isHindi => locale.languageCode == 'hi';

  String get appName => 'Agaram Care';

  String get chooseLanguage => switch (locale.languageCode) {
        'ta' => 'உங்கள் மொழியைத் தேர்வு செய்யவும்',
        'hi' => 'अपनी भाषा चुनें',
        _ => 'Choose your language',
      };

  String get continueText => switch (locale.languageCode) {
        'ta' => 'தொடரவும்',
        'hi' => 'जारी रखें',
        _ => 'Continue',
      };

  String get chooseRole => switch (locale.languageCode) {
        'ta' => 'உங்களைப் பற்றித் தெரிவிக்கவும்',
        'hi' => 'अपनी भूमिका चुनें',
        _ => 'Tell us how you will use Agaram Care',
      };

  String get patient => switch (locale.languageCode) {
        'ta' => 'நோயாளர்',
        'hi' => 'मरीज़',
        _ => 'Patient',
      };

  String get patientDescription => switch (locale.languageCode) {
        'ta' => 'உங்கள் உடல்நலம் மற்றும் சிகிச்சையை நிர்வகிக்க',
        'hi' => 'अपनी देखभाल और स्वास्थ्य यात्रा के लिए',
        _ => 'Manage your care and health journey',
      };

  String get vhn => switch (locale.languageCode) {
        'ta' => 'சுகாதார பணியாளர்',
        'hi' => 'स्वास्थ्य कार्यकर्ता',
        _ => 'Health Worker',
      };

  String get vhnDescription => switch (locale.languageCode) {
        'ta' => 'சமூகத்தில் நோயாளிகளுக்கு உதவ',
        'hi' => 'समुदाय में मरीजों की सहायता के लिए',
        _ => 'Assist patients in the community',
      };

  String get doctor => switch (locale.languageCode) {
        'ta' => 'மருத்துவர்',
        'hi' => 'डॉक्टर',
        _ => 'Doctor',
      };

  String get doctorDescription => switch (locale.languageCode) {
        'ta' => 'ஆலோசனை மற்றும் தொடர்ச்சியான சிகிச்சைக்காக',
        'hi' => 'परामर्श और देखभाल प्रबंधन के लिए',
        _ => 'For consultations and care management',
      };

  String get login => switch (locale.languageCode) {
        'ta' => 'உள்நுழைவு',
        'hi' => 'लॉग इन',
        _ => 'Sign in',
      };

  String get phoneNumber => switch (locale.languageCode) {
        'ta' => 'தொலைபேசி எண்',
        'hi' => 'फ़ोन नंबर',
        _ => 'Phone number',
      };

  String get password => switch (locale.languageCode) {
        'ta' => 'கடவுச்சொல்',
        'hi' => 'पासवर्ड',
        _ => 'Password',
      };

  String get loginDescription => switch (locale.languageCode) {
        'ta' => 'தொடர உங்கள் கணக்கில் உள்நுழையவும்',
        'hi' => 'जारी रखने के लिए अपने खाते में लॉग इन करें',
        _ => 'Sign in to continue to your care',
      };

  String get demoNotice => switch (locale.languageCode) {
        'ta' => 'இது தற்போது முன்மாதிரி உள்நுழைவு.',
        'hi' => 'यह अभी प्रोटोटाइप लॉगिन है।',
        _ => 'This is a prototype login for now.',
      };
}
